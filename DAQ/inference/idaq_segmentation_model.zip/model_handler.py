import os
import pickle
import json
import cv2
import numpy as np
import torch
import torchvision.transforms as transforms


class ModelHandler:
    def __init__(self, data, context):
        current_file_path = os.path.dirname(os.path.abspath(__file__))
        __model_config_file_path = os.path.join(current_file_path, "model.json")
        with open(__model_config_file_path, "r", encoding='utf-8') as config_file:
            __config = json.load(config_file)
            __model_file_path = os.path.join(current_file_path, __config['model_file'])
        
        self.__device = __config['device']
        __extra_files = {'inference_info' : {}}
        self.__model = torch.jit.load(__model_file_path, map_location=self.__device, _extra_files=__extra_files).eval()
    
        __inference_info = json.loads(__extra_files['inference_info'].decode('ascii'))
        self.__label_info = __inference_info['label_info']

        self.__transform = transforms.Compose([transforms.ToTensor()])

    def __call__(self, data, context):
        data = pickle.loads(data)

        if data.ndim == 2:
            data = cv2.cvtColor(data, cv2.COLOR_GRAY2BGR)
        
        height, width, *_ = data.shape

        blank_image = np.zeros((height, width), dtype=np.uint8)
        for roi_key in context:
            str_roi = context[roi_key]
            roi = json.loads(str_roi)
            roi_x, roi_y, roi_width, roi_height = roi['box']
            roi_rb_point = (roi_x + roi_width - 1, roi_y + roi_height - 1)
            cv2.rectangle(blank_image, (roi_x, roi_y), roi_rb_point, 255, -1)

        blank_image = blank_image.astype(np.int64)
        data_tensor = self.__transform(data)
        data_tensor = torch.unsqueeze(data_tensor, dim=0).to(self.__device)

        output = self.__model(data_tensor)
        output = output.to('cpu')

        output = torch.argmax(output, 1)
        output = output.cpu().data.numpy()
        output = output.squeeze(0)

        output = cv2.bitwise_and(blank_image, output)

        for i, label in enumerate(self.__label_info):
            output[output==i] = label

        output = output.astype(np.uint8)
        return pickle.dumps(output), context

    def test(self):
        """
        모델 배포 시 모델 로드 후 호출되는 부분
        Predict 정상 동작 확인을 위한 테스트 함수
        테스트가 필요한 모델의 경우 해당 함수 구현
        """

        rois = {'1':{'box':[31,86,91,83]},'2':{'box':[121,85,86,83]},'3':{'box':[206,85,84,83]},'4':{'box':[86,181,82,74]},'5':{'box':[168,179,82,74]},'6':{'box':[250,180,85,74]}}

        roi_dict = dict()
        for key in rois:
            roi_dict[key] = json.dumps(rois[key])

        input_path = 'input_data/source.png'
        test_data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), input_path)
        # test_data_path = os.path.abspath("test\\testdata\\input_data\\binary\\320x320_binary_1.png")
        test_data = cv2.imread(test_data_path, 1)
        test_data_pickle = pickle.dumps(test_data)

        # =================================================================== #

        inference_result, _ =  self.__call__(test_data_pickle, roi_dict)

        # =================================================================== #

        inference_result = pickle.loads(inference_result)

        print("Success")


if __name__ == "__main__":
    ModelHandler(None, None).test()