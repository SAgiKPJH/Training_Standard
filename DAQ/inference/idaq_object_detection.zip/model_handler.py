import os
import pickle
import cv2
import numpy as np
import torch
import subprocess
import sys

# DetectionModel을 신뢰할 수 있는 global로 등록

class ModelHandler:
    def __init__(self, data, context):
            
        model_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "last.pt")

        subprocess.check_call([sys.executable, "-m", "pip", "install", "-U", "ultralytics"])
        # 그 다음 다시 YOLO 로드
        from ultralytics import YOLO
        # self.__model = torch.load(model_file_path, weights_only=False)
        self.__model = YOLO(model_file_path)

    def __call__(self, data, context):
        data = pickle.loads(data)
        data = cv2.cvtColor(data, cv2.COLOR_GRAY2RGB)

        data = np.ascontiguousarray(data)
        predict_result = self.__model.predict(data, conf=0.25, save=True)

        output = dict()
        # {'1':{'box':[31,86,91,83]},'2':{'box':[121,85,86,83]},'3':{'box':[206,85,84,83]},'4':{'box':[86,181,82,74]},'5':{'box':[168,179,82,74]},'6':{'box':[250,180,85,74]}}
        index = 1
        for result in predict_result:
            for box in result.boxes:
                if int(box.cls.cpu().numpy()[0]) == 0:
                    xyxy = box.xyxy.cpu().numpy()[0]

                    start_x, start_y, end_x, end_y = int(xyxy[0]), int(xyxy[1]), round(xyxy[2]), round(xyxy[3])

                    width = end_x - start_x + 1
                    height = end_y - start_y + 1
                    box = [start_x, start_y, width, height]
                    output[str(index)] = {'box' : box }
                    index += 1
        
        return pickle.dumps(output), context

    # def test(self):
    #     """
    #     모델 배포 시 모델 로드 후 호출되는 부분
    #     Predict 정상 동작 확인을 위한 테스트 함수
    #     테스트가 필요한 모델의 경우 해당 함수 구현
    #     """

    #     input_path = r'D:\WorkSpace\git\mpp\Src\workflow\training\realtime_detection_transformer\dataset\images\train\1.png'
    #     # test_data_path = os.path.abspath("test\\testdata\\input_data\\binary\\320x320_binary_1.png")
    #     test_data = cv2.imread(input_path, 0)
    #     test_data_pickle = pickle.dumps(test_data)

    #     # =================================================================== #

    #     inference_result, _ =  self.__call__(test_data_pickle, None)

    #     # =================================================================== #

    #     inference_result = pickle.loads(inference_result)

    #     print(F"Success: {inference_result}")

if __name__ == "__main__":
    ModelHandler(None, None).test()
